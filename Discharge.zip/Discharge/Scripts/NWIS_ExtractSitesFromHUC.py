#NWIS_ExtractSitesFromHUC.py
#
#Description: Extracts USGS gage sites for a supplied HUC
#             using HTTP web services calling the NWIS real-time
#             data server. A feature class of the site points
#             is returned.

# import the required modules
import sys, os, arcpy
from urllib import request

# enable overwrites
arcpy.env.overwriteOutput = True

# Get the input HUC8 Number and output FC Name from the user
HUC_CODE = arcpy.GetParameterAsText(0)
Out_FC = arcpy.GetParameterAsText(1)
#Split the FC into path and name
outWS = os.path.split(Out_FC)[0]
outFC = os.path.split(Out_FC)[1]

# construct the url to retrieve all sites in the HUC with real-time data
URL = r'http://waterdata.usgs.gov/nc/nwis/inventory?' + \
      'huc_cd=' + HUC_CODE+ \
      '&index_pmcode_STATION_NM=1' + \
      '&index_pmcode_DATETIME=2' + \
      '&index_pmcode_72019=3' + \
      '&index_pmcode_72020=' + \
      '&index_pmcode_00065=4' + \
      '&sort_key=site_no' + \
      '&group_key=NONE' + \
      '&format=sitefile_output' + \
      '&sitefile_output_format=rdb' + \
      '&column_name=agency_cd' + \
      '&column_name=site_no' + \
      '&column_name=station_nm' + \
      '&column_name=dec_lat_va' + \
      '&column_name=dec_long_va' + \
      '&sort_key_2=site_no' + \
      '&html_table_group_key=NONE' + \
      '&rdb_compression=file' + \
      '&list_of_search_criteria=huc_cd%2Crealtime_parameter_selection'

           
# pull the contents of the URL into the data variable
arcpy.AddMessage("Retrieving data from NWIS site")
data = request.urlopen(URL)
dataLines = data.readlines()

# create an insert cursor to add records
recs = arcpy.InsertCursor(outFC)
# create an id iterator
id = 0
# loop through each data line
for line in data.readlines()[28:]:
    #Split the tab-separated line into a list of data elements
    linedata = line.decode("utf-8").split("\t")
    #create a new feature record
    rec = recs.newRow()
    #create a new point object for the gage site
    pt =arcpy.CreateObject("POINT")
    #add the point's id# and X,Y coordinates
    pt.id = id
    pt.X =linedata[4]
    pt.Y = linedata[3]
    #set the feature's shape as the point we just made
    rec.shape = pt
    #add the attributes to the feature table
    rec.agency = linedata[0]
    rec.site_no = linedata[1]
    rec.station_nm = linedata[2]
    #finally, add the new record to the feature class
    recs.insertRow(rec)

# remove the cursor objects    
del rec, recs

# tell the user, we're finished
arcpy.AddMessage("Gage site feature class completed")